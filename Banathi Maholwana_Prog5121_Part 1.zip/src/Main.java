import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Authentication auth = new Authentication();
        String choice;

        do {
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.println("Choose an option: ");
            choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    System.out.print("Enter username (must include '_' and up to 5 characters): ");
                    String username = scanner.nextLine();
                    System.out.print("Enter password (at least 8 characters, 1 capital letter, 1 number, 1 special character): ");
                    String password = scanner.nextLine();
                    System.out.print("Enter cell phone number (e.g., +27123456789): ");
                    String cellPhoneNumber = scanner.nextLine();

                    String registrationMessage = auth.registerUser(username, password, cellPhoneNumber);
                    System.out.println(registrationMessage);
                    break;

                case "2":
                    System.out.print("Enter username: ");
                    String loginUsername = scanner.nextLine();
                    System.out.print("Enter password: ");
                    String loginPassword = scanner.nextLine();

                    boolean loggedIn = auth.loginUser(loginUsername, loginPassword);
                    String loginMessage = auth.returnLoginStatus(loggedIn, loginUsername);
                    System.out.println(loginMessage);
                    break;

                case "3":
                    System.out.println("Existing...");
                    break;

                default:
                    System.out.println("Invalid option. Please choose again.");
            }
        } while (!choice.equals("3"));

        scanner.close();
    }
}