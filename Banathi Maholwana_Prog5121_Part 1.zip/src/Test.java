import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RegistrationLoginSystemTest {
    private RegistrationLoginSystem system;
    private RegistrationLoginSystem.User testUser;

    @BeforeEach
    public void setUp() {
        system = new RegistrationLoginSystem();
        testUser = new RegistrationLoginSystem.User(
                "ValidPass1!",
                "+27831234567",
                "John",
                "Doe"
        );
        RegistrationLoginSystem.registeredUsers.put("test_1", testUser);
    }

    @org.junit.Test
    @Test
    public void testCheckUsername_Valid() {
        assertTrue(RegistrationLoginSystem.checkUsername("user_1"));
        assertTrue(RegistrationLoginSystem.checkUsername("a_b"));
    }

    @Test
    public void testCheckUsername_Invalid() {
        assertFalse(RegistrationLoginSystem.checkUsername("username"));
        assertFalse(RegistrationLoginSystem.checkUsername("user1"));
        assertFalse(RegistrationLoginSystem.checkUsername(""));
    }

    @Test
    public void testCheckPasswordComplexity_Valid() {
        assertTrue(RegistrationLoginSystem.checkPasswordComplexity("ValidPass1!"));
        assertTrue(RegistrationLoginSystem.checkPasswordComplexity("A1@bcdefg"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid() {
        assertFalse(RegistrationLoginSystem.checkPasswordComplexity("short"));
        assertFalse(RegistrationLoginSystem.checkPasswordComplexity("nouppercase1!"));
        assertFalse(RegistrationLoginSystem.checkPasswordComplexity("NONUMBER!"));
        assertFalse(RegistrationLoginSystem.checkPasswordComplexity("NoSpecialChar1"));
    }

    @Test
    public void testCheckCellPhoneNumber_Valid() {
        assertTrue(RegistrationLoginSystem.checkCellPhoneNumber("+27831234567"));
        assertTrue(RegistrationLoginSystem.checkCellPhoneNumber("+27791234567"));
    }

    @Test
    public void testCheckCellPhoneNumber_Invalid() {
        assertFalse(RegistrationLoginSystem.checkCellPhoneNumber("0831234567"));
        assertFalse(RegistrationLoginSystem.checkCellPhoneNumber("+2783123456"));
        assertFalse(RegistrationLoginSystem.checkCellPhoneNumber("+278312345678"));
        assertFalse(RegistrationLoginSystem.checkCellPhoneNumber("+28a1234567"));
    }

    @Test
    public void testLoginUser_Successful() {
        boolean loginResult = system.loginUser("test_1", "ValidPass1!");
        assertTrue(loginResult);
    }

    @Test
    public void testLoginUser_Failed() {
        boolean loginResult = system.loginUser("test_1", "wrongpass");
        assertFalse(loginResult);
    }

    @Test
    public void testReturnLoginStatus_Successful() {
        String message = RegistrationLoginSystem.returnLoginStatus(true, testUser);
        assertEquals("Welcome John, Doe it is great to see you again.", message);
    }

    @Test
    public void testReturnLoginStatus_Failed() {
        String message = RegistrationLoginSystem.returnLoginStatus(false, testUser);
        assertEquals("Login failed.", message);
    }

    private void assertEquals(String ignoredS, String message) {
    }
}