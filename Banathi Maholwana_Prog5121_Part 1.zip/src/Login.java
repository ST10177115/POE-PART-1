import java.util.regex.Pattern;

public class Login {
    private String username;
    private String password;

    // Username validation (contains underscore and <=5 characters)
    public boolean
checkUserName(String username) {
        return username != null &&

username.contains("_") &&
                username.length() <=5;
    }
    // Password complexity check using regex
    public boolean
checkPasswordComplexity(String password) {
        String regex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
        return
Pattern.matches(regex, password);
    }

    // Cellphone validation with international code (regex created with ChatGPT)
    public boolean
checkCellPhoneNumber(String cellphone) {
        // Regex pattern: ^\+27\d{9}$ - South African numbers with country code
        String regex = "^\\+27\\d{9}$";
        return
Pattern.matches(regex, cellphone);
    }

    // Registration process with validation
    public String
registerUser(String username, String password, String cellphone)
    {
        if (!
                checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!
        checkPasswordComplexity(password));
        {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }

        // Store credentials if all validations pass
        this.username = username;
        this.password = password;
        return "user registered successfully.";
    }

    // Login verification
    public boolean loginUser(String username, String password) {
        return this.username != null &&
                this.password != null &&
this.username.equals(username)  &&

this.password.equals(password);
    }

    //Login status message generator
    public String
    returnLoginStatus(boolean isAuthenticated) {
        if (isAuthenticated) {
            String[] nameParts = username.split("_", 2);
            String firstName = nameParts[0];
            String lastName = nameParts.length > 1 ?
                    nameParts[1] : "";
            return "Welcome " + firstName +", " + lastName + " it is great to see you again.";
        }

        // Getters for testing purposes
        String getUsername;
        {
    return username; }
    }
}