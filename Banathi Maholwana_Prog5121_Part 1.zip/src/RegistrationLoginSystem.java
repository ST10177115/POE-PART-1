public class RegistrationLoginSystem {
    public static boolean checkUsername(String user1) {
    }
}
