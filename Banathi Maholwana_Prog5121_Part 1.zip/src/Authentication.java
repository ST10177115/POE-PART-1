import User.User;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class Authentication {
    private Map<String, User> users = new HashMap<>();

    public boolean checkUserName(String username) {
        return username.length() <= 5 && username.contains("_");
    }

    public boolean checkPasswordComplexity(String password) {
        return password.length() >= 8 &&
                Pattern.compile("[A-Z]").matcher(password).find() &&
                Pattern.compile("[0-9]").matcher(password).find() &&
                Pattern.compile("[^a-zA-Z0-9]").matcher(password).find();
    }

    public boolean checkCellPhoneNumber(String cellPhoneNumber) {
        return Pattern.matches("^\\+[0-9]{2}[0-9]{10}$", cellPhoneNumber);
    }

    public String registerUser(String username, String password, String cellPhoneNumber) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber(cellPhoneNumber)) {
            return "Cell phone number is incorrectly formatted or does not contain an international code, please correct the number and try again.";
        }

        users.put(username, new User(username, password, cellPhoneNumber));
        return "User successfully registered.";
    }

    public boolean loginUser(String username, String password) {
        User user = users.get(username);
        return user != null && user.getPassword().equals(password);
    }

    public String returnLoginStatus(boolean loggedIn, String username) {
        if (loggedIn) {
            return "Welcome " + username + ", it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }
}

